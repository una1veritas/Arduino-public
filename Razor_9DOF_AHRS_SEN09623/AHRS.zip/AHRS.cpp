/********************************************************************************

	AHRS for the original Sparkfun Razor (SEN-09623)
	http://www.sparkfun.com/products/9623

	Gyro:			LY530ALH and LPR530ALH
	Accelerometer: 	ADXL345
	Magnetometer:	HMC5843 

	Data is output over the UART at 115200 baud in the format:
	!ERR:<msg>
	!ANG:<roll degrees>,<pitch degrees>,<yaw degrees>

	You will need WebbotLib Version 2.08 or higher to compile.

	You will need to edit the 'makefile' and change the line saying:-
		# The library where WebbotLib is installed
		WEBBOT		   = ../../..
	To reflect where you have installed WebbotLib

	To compile the project just type in: 
		make
	from the command line


	Based on code by Doug Weibel, Jose Julio, Jordi Munoz and William Premerlani
	but rewritten for WebbotLib

	Version 1.0		4 October 2011		First release
********************************************************************************/

#include "hardware.h"
// Needs the Math library from the compiler
#include <Math.h>
// Needs the following files from WebbotLib
#include <Maths/Vector3D.h>
#include <Maths/DCM.h>

// #define ToRad(x) (x * (M_PI/180.0))
// #define ToDeg(x) (x * (180.0/M_PI))


// Run the loop every 20ms
#define LOOP_TIME 20000

DCM matrix;

double magHeadingRadians;

// Define all functions
void readSensors(void);


// The sensor values
Vector3D accelVector;		// in G
Vector3D magnetomVector;	// in raw values
Vector3D gyroVector;		// in degrees per second


/* ============= Initialise the hardware =============== */
void appInitHardware(void) {
	initHardware();

	// Calibrate the accelerometer as described in the WebbotLib manual
	// so that each axis returns values in the range -1000 to +1000
	acceleration.calibrateX(-1000,1014);
	acceleration.calibrateY(-1068, 985);
	acceleration.calibrateZ(-1100, 860);
}




/* ============= Initialise the software =============== */
TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	readSensors();

	// The HMC magnetometer is a bit 'flakey' so test if it is working
	if(!compass.isFunctional()){
		cout.print_P( PSTR("!ERR: Magnetometer not working\r\n") );
		// Make the status LED flash
		setError(1);
	}

	return LOOP_TIME;
}



/* =====================================================

 	This is the main loop - should run every 20ms

*/
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart) {

	// Wait till everything sent out by the previous loop
	while(uart0.isBusy()){
	}

	// Read the sensors
	readSensors();

	// Update the DCM
	matrix.gyroDegrees(gyroVector);

	// Apply drift correction
	matrix.driftCorrection(accelVector, magHeadingRadians);



	cout.print('!');

	// Attitude
	cout.print_P(PSTR("ANG:")); cout << matrix.getRollDegrees() << ',' << matrix.getPitchDegrees() << ',' << matrix.getYawDegrees();


	// Magnetometer raw values
	cout.print_P(PSTR(",MAG:,"));magnetomVector.dump(cout); 

	// Gyro values
//	cout.print_P(PSTR(",GYR:,"));gyroVector.dump(cout); 

	// accel vector
//	cout.print_P(PSTR(",ACL:,"));accelVector.dump(cout); 


	cout.println();


	// put out actual loop duration
	//cout.print(clockGetus() - loopStart); cout.println();


	return LOOP_TIME;	// run every 20ms
}


/* =====================================================
*	adjustCompass
*	Parameter: 	0 = get the X value
*				1 = get the Y value
*				2 = get the Z value
*
*	Uses compassIndex to decide which value to use from the device
*	as each board may have the compass mounted in a different manner.
*	Use compassSign to optionally reverse the value
*
*	Returns the raw magnetometer value for the axis
*/

static const uint8_t compassIndex[3] = { 1, 0, 2 };	// Actual x,y,z = device y,x,z
static const int8_t  compassSign[3] = { -1, -1, -1};	// x,y,z are all inverted

static int16_t adjustCompass(uint8_t axis){
	uint8_t index = compassIndex[axis];
	int16_t rtn = 0;
	switch(index){
		case 0:
			rtn = compass.getRawX();
			break;
		case 1:
			rtn = compass.getRawY();
			break;
		case 2:
			rtn = compass.getRawZ();
			break;
	}
	if(compassSign[axis]<0){
		rtn *= -1;
	}

	return rtn;
}

/* =====================================================
*	adjustAccel
*	Parameter: 	0 = get the X value
*				1 = get the Y value
*				2 = get the Z value
*
*	Uses accelIndex to decide which value to use from the device
*	as each board may have the accelerometer mounted in a different manner.
*	Use accelSign to optionally reverse the value
*
*	Returns the accelerometer value for the axis in whole G
*/

static const uint8_t accelIndex[3] = { 1, 0, 2 };		// Actual x,y,z = device y,x,z
static const int8_t  accelSign[3] = {  1, 1, 1};		// x,y,z are not inverted

static double adjustAccel(uint8_t axis){
	uint8_t index = accelIndex[axis];
	double rtn = 0;
	switch(index){
		case 0:
			rtn = acceleration.getX();
			break;
		case 1:
			rtn = acceleration.getY();
			break;
		case 2:
			rtn = acceleration.getZ();
			break;
	}
	if(accelSign[axis]<0){
		rtn *= -1;
	}

	rtn /= 1000.0;	// convert from mG to G
	return rtn;
}


/* =====================================================
*	adjustGyro
*	Parameter: 	0 = get the X value
*				1 = get the Y value
*				2 = get the Z value
*
*	Uses gyroIndex to decide which value to use from the device
*	as each board may have the gyro mounted in a different manner.
*	Use gyroSign to optionally reverse the value
*
*	Returns the gyro value for the axis in degrees per second
*/
static const uint8_t gyroIndex[3] = { 0, 1, 2 };		// Actual x,y,z = device x,y,z
static const int8_t  gyroSign[3] = {  -1, 1, -1};		// x inverted, y not,z inverted


static double adjustGyro(uint8_t axis){
	GYRO_TYPE rtn = 0;
	uint8_t index = gyroIndex[axis];
	switch(index){
		case 0:
			rtn = gyro.getX();
			break;
		case 1:
			rtn = gyro.getY();
			break;
		case 2:
			rtn = gyro.getZ();
			break;
	}
	if(gyroSign[axis]<0){
		rtn *= -1;
	}

	return rtn;
}


/* =====================================================
*
*	Read all the sensors and set up vectors
*
*/
void readSensors(void){

	// Read each device
	acceleration.read();
	compass.read();
	gyro.read();


	// Adjust accelerometer axes and signs, result is in G
	accelVector.set(adjustAccel(0),adjustAccel(1),adjustAccel(2));

	// Adjust compass axes and signs
	magnetomVector.set(adjustCompass(0),adjustCompass(1),adjustCompass(2));

	// Adjust gyro axes and signs, to get values in degrees
	gyroVector.set(adjustGyro(0),adjustGyro(1),adjustGyro(2));



	if(compass.isFunctional()){
		// Calculate the compass magnetic heading
		// taking into account the current pitch and roll
		double roll = matrix.getRollRadians();
		double pitch = matrix.getPitchRadians();
		double cos_roll = cos(roll);
	  	double sin_roll = sin(roll);
	  	double cos_pitch = cos(pitch);
	  	double sin_pitch = sin(pitch);

	  	// Tilt compensated Magnetic field X:
	  	double MAG_X = magnetomVector.x*cos_pitch + magnetomVector.y*sin_roll*sin_pitch + magnetomVector.z*cos_roll*sin_pitch;
	  	// Tilt compensated Magnetic field Y:
	  	double MAG_Y = magnetomVector.y*cos_roll - magnetomVector.z*sin_roll;
	  	// Magnetic Heading
	  	magHeadingRadians = atan2(-MAG_Y,MAG_X);
	}else{
		// No option but to let the yaw value drift
		magHeadingRadians = matrix.getYawRadians();
	}
}







