#include "../hardware.h"
static const char PROGMEM name_acceleration[] = "acceleration";
static const char PROGMEM name_compass[] = "compass";
static const char PROGMEM name_i2c[] = "i2c";
static const char PROGMEM name_uart0[] = "uart0";
static const char PROGMEM name_gyro[] = "gyro";
static const char PROGMEM unknown[] = "?";

#define NUM_DEVICES 5
static const void* PROGMEM tbl[]={
	&_acceleration_, name_acceleration,
	&_compass_, name_compass,
	&_i2c_, name_i2c,
	&__C_uart0, name_uart0,
	&_gyro_, name_gyro
	};

const char* getDeviceName(const void* device){
	const char* rtn = unknown;
	for(int i=0 ; i<NUM_DEVICES*2; i+=2){
		const void* addr = (const void*)pgm_read_word(&tbl[i]);
		if( addr == device){
			rtn = (const void*)pgm_read_word(&tbl[i+1]);
		}
	}
	return rtn;
}
