
// Include hardware info for this device	
#include <avr/io.h>

		
#if defined (__AVR_ATmega328P__)
// Each timer has A,B channels etc
// Map the UART vectors
#  define USART0_RX_vect USART_RX_vect
#  define USART0_TX_vect USART_TX_vect
#else
#  error "Processor mismatch in utilities.xsl"
#endif
			
#include "lib_timerdef.h"
#include <timer.h>
#include <errors.h>
// Variable used by main library to link in this module
uint8_t PROGMEM _timer_compare_error = TIMER_COMPARE_CALLBACK_EXISTS;
// The dummy routine used to denote that the compare is in use
// Only ever called from here but not static to avoid unused warnings
void nullTimerCompareCallback(const TimerCompare *timer_compare, void* data){}

// Interrupt handler for  TIMER0_COMPAREA compare interrupt
ISR(TIMER0_COMPA_vect){
	__timer_compareService(TIMER0_COMPAREA);
}
// Interrupt handler for  TIMER0_COMPAREB compare interrupt
ISR(TIMER0_COMPB_vect){
	__timer_compareService(TIMER0_COMPAREB);
}
// Interrupt handler for  TIMER1_COMPAREA compare interrupt
ISR(TIMER1_COMPA_vect){
	__timer_compareService(TIMER1_COMPAREA);
}
// Interrupt handler for  TIMER1_COMPAREB compare interrupt
ISR(TIMER1_COMPB_vect){
	__timer_compareService(TIMER1_COMPAREB);
}
// TIMER2_COMPAREA is in use
static void __attribute__ ((constructor)) init_TIMER2_COMPAREA(void){
	TimerDataCompare* data = compareGetData(TIMER2_COMPAREA);
	data->compare_callback = &nullTimerCompareCallback;
}

// Interrupt handler for  TIMER2_COMPAREB compare interrupt
ISR(TIMER2_COMPB_vect){
	__timer_compareService(TIMER2_COMPAREB);
}
