#define BUILDING_LIBRARY
#include "lib_iopins.h"
#include <pinChange.h>
const uint8_t NUM_PCINT_PINS = 18;
const IOPin* PROGMEM PCINT_PINS[]={null,null,null,B3,null,B5,null,null,null,null,null,null,null,null,null,null,D0,D1};
PIN_CHANGE pcCallbacks[18];
