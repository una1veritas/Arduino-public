#define BUILDING_LIBRARY
#include <avr/io.h>
#include <libdefs.h>
#include <timer.h>
extern const PROGMEM Timer PROGMEM pgm_Timers[];
void __initTimers(void){
 
// Set Timer2 to the following:-
//		Mode 	 = TIMER_MODE_CTC_OCR
//		Prescale = 1024
	// Save the timer mode
	timerGetData(&pgm_Timers[2])->mode = TIMER_MODE_CTC_OCR;
	// Set the timer mode
	
	// Mode TIMER_MODE_CTC_OCR is 2
	// Assume current mode settings are all 0	
		
			
	if(2 & 1){
		sbi(TCCR2A,WGM20);
	} 
		
			
	if(2 & 2){
		sbi(TCCR2A,WGM21);
	} 
		
			
	if(2 & 4){
		sbi(TCCR2B,WGM22);
	} 
		
	// Top is stored in Compare A OCR
				OCR2A = 250;			
				
	// Turn on the timer by setting prescaler
	timerGetData(&pgm_Timers[2])->prescale_value = 1024;
	TCCR2B |= 7;
	}
